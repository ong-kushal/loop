# SEO update

Added a crawlable public homepage, four standalone content pages, metadata, structured data, a 1200x630 social card, robots.txt, sitemap.xml, and a GitHub Pages workflow that creates a deploy staging directory and injects the real Pages URL. App-only hash routes set noindex. See SEO_SETUP.md for Search Console steps and the current crawlability limitation for individual posts/profiles.
