# Loop SEO setup and launch checklist

This update adds an indexable public homepage, descriptive public information pages, canonical URLs, Open Graph/Twitter share metadata, structured data, `robots.txt`, and an XML sitemap.

## What is included

- `index.html`: crawlable public homepage with a descriptive H1, product explanation, feature summaries and FAQs.
- `about.html`, `features.html`, `community-guidelines.html`, `privacy.html`: independent pages with their own titles, descriptions and canonical URLs.
- `assets/loop-social-preview.png`: 1200 x 630 social sharing image.
- `robots.txt` and `sitemap.xml`: crawl instructions and the public-page sitemap.
- `.github/workflows/pages.yml`: builds `_site` and injects the actual `https://OWNER.github.io/REPOSITORY/` URL automatically. It also publishes all SEO files (and avoids the earlier multi-line artifact path issue).
- The SPA app-only routes set a `noindex` directive; the root URL remains the public SEO landing page.

## Deploy

Commit and push the complete project to the `main` branch. GitHub Actions will publish the static site. When the workflow completes, check these URLs by replacing the example base with your live Pages URL:

- `/`
- `/about.html`
- `/features.html`
- `/community-guidelines.html`
- `/privacy.html`
- `/robots.txt`
- `/sitemap.xml`
- `/assets/loop-social-preview.png`

The workflow derives the project-site URL from the GitHub owner and repository name, so no manual username placeholder should be needed for GitHub Pages.

## Submit to search engines

1. Open Google Search Console: <https://search.google.com/search-console>.
2. Add a **URL-prefix** property using your exact live GitHub Pages URL, including the repository path and trailing slash (for example `https://USERNAME.github.io/loop/`).
3. Complete one of the verification methods offered by Search Console. If using the HTML-tag method, add the verification meta tag to `index.html`, commit and deploy, then click Verify.
4. In Search Console → Sitemaps, submit `sitemap.xml` (or the full sitemap URL).
5. Use URL Inspection on the homepage and key public pages. After the live test passes, request indexing of the homepage.
6. Optional: add the same site to Bing Webmaster Tools and submit the sitemap: <https://www.bing.com/webmasters/>.

Submitting a sitemap and requesting indexing are discovery hints, not ranking guarantees. Google may take days or weeks to crawl and decide whether to index pages.

## Important limitations

- Loop's app interface is client-rendered and uses hash routes (`#/post/...`, `#/profile/...`). Search engines generally do not treat fragments as independent crawlable URLs. The new sitemap deliberately lists only public static pages; private feed, inbox, messages, saved posts and account routes are not listed or indexed.
- To make individual user posts and profiles reliably discoverable in search, Loop would need crawlable clean URLs plus server-side rendering or a static/edge pre-rendering process, and a user-controlled indexing/privacy setting. This is a separate architecture upgrade.
- The public HTML pages describe the actual features in the current starter app. Keep them updated as product behavior changes.
- Do not add keyword stuffing, fake ratings, fake testimonials, automatically generated thin pages, or copied content. Useful original content and a good user experience matter more than repeating keywords.

## Content plan to build rankings over time

Create genuinely useful, original pages around topics the product can answer, such as:

- How Loop's interest-aware For You feed works
- Why Loop has no like or dislike buttons
- Photo and short-video sharing on Loop
- How optional location-based discovery works
- Tips for having thoughtful conversations online

Only publish articles that provide real information. Each page should have a unique title, one clear H1, helpful subheadings, descriptive internal links and a page-specific meta description.
